Database version control, made easy!
=

**dbv.php** is a database version control web application featuring schema management, revision scripts, and more!

Check out the **[project website](http://dbv.vizuina.com)** for more details, features and documentation.

[![dbv.php](http://dbv.vizuina.com/img/screenshot-main.png)](http://dbv.vizuina.com)